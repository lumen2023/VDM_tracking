# Dorm-to-Class Navigation Result

## Task Summary

This experiment combines a campus route, vehicle parameters, an adaptive Pure Pursuit controller, closed-loop simulation, and quantitative evaluation. The start, destination, permitted route, and excluded road sections are taken from the annotated campus map.

## Route and Map

- GPX file: `data/gpx/dorm_to_class_map_route.gpx`
- Route length: 798.2 m
- Source GPX points: 50
- Resampled points: 1598
- Maximum source-point spacing: 19.0 m
- Start: 31.8856980, 118.8223350
- Destination: 31.8889160, 118.8181900

The route is converted from WGS84 coordinates to a local East-North frame in metres. The reference path and vehicle trajectory use the same origin as the offline OSM GeoJSON map. The current GPX was digitized from the annotated map and is a planning reference rather than a surveyed vehicle path.

## Controller

The controller selects its target by path distance. Lookahead increases with speed and lateral error, while curvature preview reduces the target speed before a sharp turn. The front road-wheel angle and its rate of change are limited using the vehicle parameters. A stopping-distance constraint reduces speed near the destination.

## Tracking Result

| Metric | Result |
| --- | ---: |
| Destination reached | True |
| Lateral-error RMSE | 0.033 m |
| Lateral-error P95 | 0.011 m |
| Maximum lateral error | 0.595 m |
| Final position error | 0.028 m |
| Maximum road-wheel angle | 33.36 deg |
| Maximum speed | 1.50 m/s |
| Simulation time | 541.9 s |

## Real-Vehicle Interface

The supplied vehicle software provides path recording, PP tracking, and RViz display. Before a full test, the route should be recorded while the vehicle is driven manually at low speed. The test log should include `/gps_odom`, `/vehicleStateSet`, and `/vehicleCmdSet` so that the same metrics can be calculated from the real trajectory.

## Limitation

This result verifies the controller and analysis code on the map-derived route. It is not an autonomous real-vehicle result. Map alignment and positioning errors must be addressed by recording a dense GNSS/RTK route on site before vehicle operation.
