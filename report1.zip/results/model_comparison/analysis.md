# Vehicle-Model Reconstruction and Comparison

## Experiment Setup

- Data file: `data/modeling/controlled_benchmark.csv`
- Samples: 1801
- Median sample interval: 0.050 s
- Duration: 90.0 s
- Calibration samples: 1080
- Held-out evaluation samples: 721
- All models use the same speed and steering inputs and start from the same pose.

## Identified Parameters

- Effective wheelbase: 0.936 m
- Steering bias: 1.184 deg
- Yaw-rate time constant: 0.340 s
- Understeer coefficient: 0.0472 s^2/m
- Steering-input delay: 0.175 s

## Held-Out Evaluation

| Model | Position RMSE [m] | Position P95 [m] | Heading RMSE [deg] | Yaw-rate RMSE [deg/s] |
| --- | ---: | ---: | ---: | ---: |
| kinematic_rear | 10.003 | 11.423 | 5.561 | 0.883 |
| kinematic_cg | 9.469 | 10.483 | 5.338 | 0.879 |
| dynamic_yaw | 0.296 | 0.372 | 1.149 | 0.347 |

## Discussion

- The rear-axle kinematic model is the simplest option and is suitable for low-speed tests with gradual steering changes.
- The center-of-gravity kinematic model gives a better geometric description of turning but still assumes an instantaneous steering response.
- The reduced dynamic model represents steering delay, yaw lag, and speed-dependent understeer, so it is more suitable when steering changes are faster.
- `dynamic_yaw` has the lowest held-out yaw-rate error, with an RMSE of 0.347 deg/s.

## Data Limitation

The supplied `robot_car.bag` contains no topics or messages. The current result therefore uses a deterministic synthetic dataset to test the implementation and must not be interpreted as a real-vehicle result. A new vehicle log can be converted to the same CSV format and evaluated with the same program.
