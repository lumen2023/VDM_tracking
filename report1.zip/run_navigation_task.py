"""Run the complete dorm-to-class Adaptive Pure Pursuit workflow."""

import argparse
from pathlib import Path

from vdm_lab.common.basemap import load_basemap
from vdm_lab.common.logging import save_records, save_reference_path
from vdm_lab.common.simulation import build_reference_path, run_simulation
from vdm_lab.common.vector_map import infer_geojson_bounds
from vdm_lab.common.types import LabConfig
from vdm_lab.config.vehicle_params import make_vehicle_config
from vdm_lab.navigation import (
    compute_navigation_metrics,
    save_metrics_json,
    save_navigation_dashboard,
    save_navigation_report,
    save_route_check_csv,
)
from vdm_lab.solutions import adaptive_pure_pursuit


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--gpx",
        default="data/gpx/dorm_to_class_map_route.gpx",
        help="Dense route recorded or exported from dorm to classroom.",
    )
    parser.add_argument(
        "--basemap-file",
        default="data/planet_118.792,31.875_118.837,31.902.osm.geojson.xz",
        help="Offline GeoJSON map that covers the GPX route.",
    )
    parser.add_argument("--target-speed", type=float, default=1.5)
    parser.add_argument("--waypoint-ds", type=float, default=0.5)
    parser.add_argument(
        "--output-dir",
        default="results/dorm_to_class_demo",
    )
    parser.add_argument(
        "--strict-route",
        action="store_true",
        help="Reject a GPX whose raw points contain a gap larger than 50 m.",
    )
    parser.add_argument(
        "--unconfirmed-route",
        action="store_true",
        help="Mark a replacement GPX as not yet confirmed by the group.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    route_file = Path(args.gpx)
    basemap_file = Path(args.basemap_file)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    bounds = infer_geojson_bounds(basemap_file)
    if bounds is None:
        raise ValueError(
            "The offline map filename must contain west,south_east,north bounds."
        )
    west, south, east, north = bounds

    config = LabConfig(vehicle=make_vehicle_config("sydl_smartcar"))
    config.sim.gpx_file = str(route_file)
    config.sim.waypoint_ds = args.waypoint_ds
    config.sim.target_speed = args.target_speed
    config.sim.speed_mode = "low"
    config.sim.coordinate_origin_lon = (west + east) / 2.0
    config.sim.coordinate_origin_lat = (south + north) / 2.0
    config.sim.basemap = "geojson"
    config.sim.basemap_file = str(basemap_file)
    config.sim.basemap_max_pixels = 2200
    config.sim.view_mode = "follow"
    config.sim.follow_radius = 35.0
    config.controller.pp_base_lookahead = 1.20
    config.controller.pp_speed_gain = 0.80
    config.controller.pp_min_lookahead = 1.20
    config.controller.pp_max_lookahead = 4.00
    config.controller.pp_lateral_error_gain = 0.25
    config.controller.pp_max_lateral_accel = 0.80
    config.controller.pp_curvature_preview_m = 12.0

    path = build_reference_path(config)
    metadata = getattr(path, "gpx_metadata", {})
    if args.strict_route and metadata.get("max_raw_gap_m", 0.0) > 50.0:
        raise ValueError(
            "The GPX has a raw point gap larger than 50 m. "
            "Record or export a denser route before the real-vehicle test."
        )
    path, records, _ = run_simulation(
        adaptive_pure_pursuit,
        config=config,
        path_override=path,
    )

    metrics = compute_navigation_metrics(path, records)
    basemap = load_basemap(path, config.sim)
    save_records(output_dir, records)
    save_reference_path(output_dir, path)
    save_metrics_json(output_dir / "metrics.json", metrics)
    save_route_check_csv(output_dir / "route_check.csv", path)
    save_navigation_dashboard(
        output_dir / "navigation_dashboard.png",
        path,
        records,
        metrics,
        basemap=basemap,
        route_confirmed=not args.unconfirmed_route,
    )
    save_navigation_report(
        output_dir / "navigation_report.md",
        route_file,
        path,
        metrics,
        metadata,
        route_confirmed=not args.unconfirmed_route,
    )

    print(f"route={route_file}")
    print(f"output_dir={output_dir}")
    print(f"route_length={metrics['route_length_m']:.1f} m")
    print(f"reached_goal={metrics['reached_goal']}")
    print(f"rms_lateral_error={metrics['rms_lateral_error_m']:.3f} m")
    print(f"p95_lateral_error={metrics['p95_lateral_error_m']:.3f} m")
    print(f"finish_error={metrics['finish_error_m']:.3f} m")


if __name__ == "__main__":
    main()
