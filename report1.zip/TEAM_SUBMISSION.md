# VDM Course Project Submission

This submission contains two parts: vehicle-model reconstruction and a dorm-to-class navigation task based on Pure Pursuit.

## 1. Vehicle-Model Reconstruction

I implemented and compared three models:

- a rear-axle kinematic bicycle model;
- a center-of-gravity kinematic bicycle model;
- a reduced dynamic yaw model with steering delay, yaw response lag, and an understeer term.

The comparison program uses the same speed and steering inputs for all three models. The first 60% of the samples are used for parameter identification, while the remaining 40% are kept for evaluation. The output includes identified parameters, numerical error metrics, and a comparison figure.

The supplied `robot_car.bag` contains no topics or messages, so it cannot be used as real-vehicle evidence. I therefore used a deterministic synthetic dataset to test the implementation. The dataset and every related result are labelled as synthetic.

Run this part with:

```bash
python3 run_model_comparison.py --generate-benchmark
```

## 2. Dorm-to-Class Navigation

The navigation route was digitized from the annotated campus map in `docs/assets/dorm_to_class_annotated_map.jpg`. The southeast orange marker is the start, the northwest orange marker is the goal, the yellow line is the permitted route, and the red hatched sections are excluded.

The resulting GPX route is 798.2 m long. It is converted to a local East-North coordinate frame and resampled at 0.5 m intervals. The controller is an adaptive Pure Pursuit implementation with:

- speed- and error-dependent lookahead distance;
- curvature-based speed reduction;
- steering-angle and steering-rate limits;
- controlled braking near the destination.

Run this part with:

```bash
python3 run_navigation_task.py
```

The simulation reached the destination with a lateral-error RMSE of 0.033 m and a final position error of 0.028 m. The maximum road-wheel angle was 33.36 degrees, below the vehicle limit of 45 degrees.

## 3. Reproduction

Install the repository dependencies and run both parts:

```bash
python3 -m pip install -r requirements.txt
bash scripts/run_all_tasks.sh
```

On Windows PowerShell:

```powershell
python -m pip install -r requirements.txt
python run_model_comparison.py --generate-benchmark
python run_navigation_task.py
python -m unittest discover -s tests -v
```

All three automated tests pass in the submitted version.

## 4. Current Limitations

- The model comparison currently uses synthetic data because the supplied bag is empty. Real-vehicle conclusions require a new ROS bag containing `/gps_odom`, `/vehicleStateSet`, and `/vehicleCmdSet`.
- The campus route was digitized from a map image. Before an autonomous vehicle test, the route should be recorded on site with GNSS/RTK while the vehicle is driven manually at low speed.
