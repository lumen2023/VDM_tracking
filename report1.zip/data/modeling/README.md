# Vehicle Experiment Data

`controlled_benchmark.csv` is a deterministic synthetic dataset used to test the identification code. It is not real-vehicle evidence.

Real logs must use these columns:

```text
time_s,speed_mps,steering_rad,x_m,y_m,yaw_rad,yaw_rate_radps
```

On the vehicle computer, record the required ROS1 topics:

```bash
rosbag record -O vdm_vehicle_model.bag /gps_odom /vehicleStateSet /vehicleCmdSet
```

Then export and analyze the bag inside the vehicle ROS environment:

```bash
python3 scripts/export_vehicle_model_rosbag.py \
  vdm_vehicle_model.bag data/modeling/real_vehicle.csv

python3 run_model_comparison.py \
  --input data/modeling/real_vehicle.csv \
  --output-dir results/model_comparison_real
```

Use an open area, a trained safety driver, the physical emergency stop, and several low-speed steering excitations. The default exporter uses the measured road-wheel angle from `/vehicleStateSet`; pass `--steering-source command` only when command-delay identification is intentional.
