"""Run vehicle-model identification and held-out comparison."""

import argparse
import json
from pathlib import Path

from vdm_lab.config.vehicle_params import make_vehicle_config
from vdm_lab.modeling.benchmark import generate_benchmark
from vdm_lab.modeling.comparison import (
    compute_prediction_metrics,
    save_identified_parameters,
    save_metrics_csv,
    save_model_comparison_plot,
)
from vdm_lab.modeling.data import load_experiment_csv
from vdm_lab.modeling.identification import identify_dynamic_yaw_model
from vdm_lab.modeling.models import (
    simulate_dynamic_yaw,
    simulate_kinematic_cg,
    simulate_kinematic_rear,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Reconstruct and compare bicycle models using a normalized experiment CSV."
    )
    parser.add_argument(
        "--input",
        default="data/modeling/controlled_benchmark.csv",
        help="Normalized experiment CSV.",
    )
    parser.add_argument(
        "--output-dir",
        default="results/model_comparison",
        help="Directory for metrics, parameters, plot, and analysis.",
    )
    parser.add_argument(
        "--vehicle",
        default="sydl_smartcar",
        help="Vehicle parameter set used as the identification prior.",
    )
    parser.add_argument("--calibration-ratio", type=float, default=0.60)
    parser.add_argument(
        "--generate-benchmark",
        action="store_true",
        help="Regenerate the deterministic synthetic benchmark before analysis.",
    )
    return parser.parse_args()


def _write_analysis(path, data, parameters, metrics, evaluation_start):
    ranked = sorted(metrics, key=lambda row: row["yaw_rate_rmse_degps"])
    best = ranked[0]
    lines = [
        "# Vehicle-Model Reconstruction and Comparison",
        "",
        "## Experiment Setup",
        "",
        f"- Data file: `{data.source}`",
        f"- Samples: {len(data.time)}",
        f"- Median sample interval: {data.median_dt_s:.3f} s",
        f"- Duration: {data.duration_s:.1f} s",
        f"- Calibration samples: {evaluation_start}",
        f"- Held-out evaluation samples: {len(data.time) - evaluation_start}",
        "- All models use the same speed and steering inputs and start from the same pose.",
        "",
        "## Identified Parameters",
        "",
        f"- Effective wheelbase: {parameters['wheelbase_m']:.3f} m",
        f"- Steering bias: {parameters['steering_bias_rad'] * 180.0 / 3.141592653589793:.3f} deg",
        f"- Yaw-rate time constant: {parameters['yaw_time_constant_s']:.3f} s",
        f"- Understeer coefficient: {parameters['understeer_s2pm']:.4f} s^2/m",
        f"- Steering-input delay: {parameters['delay_s']:.3f} s",
        "",
        "## Held-Out Evaluation",
        "",
        "| Model | Position RMSE [m] | Position P95 [m] | Heading RMSE [deg] | Yaw-rate RMSE [deg/s] |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for row in metrics:
        lines.append(
            f"| {row['model']} | {row['position_rmse_m']:.3f} | "
            f"{row['position_p95_m']:.3f} | {row['yaw_rmse_deg']:.3f} | "
            f"{row['yaw_rate_rmse_degps']:.3f} |"
        )
    lines.extend(
        [
            "",
            "## Discussion",
            "",
            "- The rear-axle kinematic model is the simplest option and is suitable for low-speed tests with gradual steering changes.",
            "- The center-of-gravity kinematic model gives a better geometric description of turning but still assumes an instantaneous steering response.",
            "- The reduced dynamic model represents steering delay, yaw lag, and speed-dependent understeer, so it is more suitable when steering changes are faster.",
            f"- `{best['model']}` has the lowest held-out yaw-rate error, with an RMSE of {best['yaw_rate_rmse_degps']:.3f} deg/s.",
            "",
            "## Data Limitation",
            "",
            "The supplied `robot_car.bag` contains no topics or messages. The current result therefore uses a deterministic synthetic dataset to test the implementation and must not be interpreted as a real-vehicle result. A new vehicle log can be converted to the same CSV format and evaluated with the same program.",
            "",
        ]
    )
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def main():
    args = parse_args()
    input_path = Path(args.input)
    if args.generate_benchmark or not input_path.exists():
        generate_benchmark(input_path)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    data = load_experiment_csv(input_path)
    vehicle = make_vehicle_config(args.vehicle)
    parameters = identify_dynamic_yaw_model(
        data,
        nominal_wheelbase_m=vehicle.wheelbase,
        calibration_ratio=args.calibration_ratio,
    )

    shared = {
        "wheelbase_m": parameters["wheelbase_m"],
        "steering_bias_rad": parameters["steering_bias_rad"],
        "delay_s": parameters["delay_s"],
    }
    predictions = [
        simulate_kinematic_rear(data, **shared),
        simulate_kinematic_cg(data, rear_length_m=vehicle.lr, **shared),
        simulate_dynamic_yaw(
            data,
            rear_length_m=vehicle.lr,
            yaw_time_constant_s=parameters["yaw_time_constant_s"],
            understeer_s2pm=parameters["understeer_s2pm"],
            **shared,
        ),
    ]
    evaluation_start = parameters["calibration_samples"]
    metrics = [
        compute_prediction_metrics(data, prediction, evaluation_start)
        for prediction in predictions
    ]

    save_identified_parameters(output_dir / "identified_parameters.json", parameters)
    save_metrics_csv(output_dir / "metrics.csv", metrics)
    save_model_comparison_plot(
        output_dir / "model_comparison.png",
        data,
        predictions,
        evaluation_start,
    )
    _write_analysis(
        output_dir / "analysis.md",
        data,
        parameters,
        metrics,
        evaluation_start,
    )
    summary = {
        "input": str(input_path),
        "source_kind": "controlled_synthetic"
        if "controlled_benchmark" in input_path.name
        else "user_experiment",
        "samples": len(data.time),
        "duration_s": data.duration_s,
        "calibration_ratio": args.calibration_ratio,
    }
    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"input={input_path}")
    print(f"output_dir={output_dir}")
    for row in metrics:
        print(
            f"{row['model']}: position_rmse={row['position_rmse_m']:.3f} m, "
            f"yaw_rate_rmse={row['yaw_rate_rmse_degps']:.3f} deg/s"
        )


if __name__ == "__main__":
    main()
