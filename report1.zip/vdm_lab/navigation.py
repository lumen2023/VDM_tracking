"""Reporting helpers for the end-to-end campus navigation experiment."""

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from vdm_lab.common.visualization import draw_basemap


def compute_navigation_metrics(path, records):
    lateral_error = np.abs([record.lateral_error for record in records])
    heading_error = np.abs([record.heading_error for record in records])
    speed = np.asarray([record.speed for record in records], dtype=float)
    steering = np.abs([record.steer for record in records])
    trajectory_x = np.asarray([record.x for record in records], dtype=float)
    trajectory_y = np.asarray([record.y for record in records], dtype=float)
    traveled = float(
        np.sum(np.hypot(np.diff(trajectory_x), np.diff(trajectory_y)))
    )
    finish_error = float(
        np.hypot(trajectory_x[-1] - path.x[-1], trajectory_y[-1] - path.y[-1])
    )
    return {
        "route_length_m": float(path.s[-1]),
        "traveled_distance_m": traveled,
        "duration_s": float(records[-1].time),
        "mean_lateral_error_m": float(np.mean(lateral_error)),
        "rms_lateral_error_m": float(np.sqrt(np.mean(lateral_error**2))),
        "p95_lateral_error_m": float(np.percentile(lateral_error, 95.0)),
        "max_lateral_error_m": float(np.max(lateral_error)),
        "mean_heading_error_deg": float(np.rad2deg(np.mean(heading_error))),
        "max_steering_deg": float(np.rad2deg(np.max(steering))),
        "mean_speed_mps": float(np.mean(speed)),
        "max_speed_mps": float(np.max(speed)),
        "finish_error_m": finish_error,
        "reached_goal": bool(finish_error < 1.5 and speed[-1] < 0.5),
        "samples": len(records),
    }


def save_navigation_dashboard(
    output_file,
    path,
    records,
    metrics,
    basemap=None,
    route_confirmed=False,
):
    time = np.asarray([record.time for record in records], dtype=float)
    x = np.asarray([record.x for record in records], dtype=float)
    y = np.asarray([record.y for record in records], dtype=float)
    error = np.asarray([record.lateral_error for record in records], dtype=float)
    speed = np.asarray([record.speed for record in records], dtype=float)
    target_speed = np.asarray([record.target_speed for record in records], dtype=float)
    steer = np.rad2deg([record.steer for record in records])
    curvature = np.asarray([record.curvature for record in records], dtype=float)
    normal_accel = np.asarray([record.normal_accel for record in records], dtype=float)

    fig, axes = plt.subplots(2, 3, figsize=(15.5, 8.8), constrained_layout=True)
    draw_basemap(axes[0, 0], basemap, opacity=0.66)
    axes[0, 0].plot(path.x, path.y, color="#111827", linewidth=1.7, label="reference")
    axes[0, 0].plot(x, y, color="#2563eb", linewidth=1.2, label="vehicle")
    axes[0, 0].scatter(path.x[0], path.y[0], color="#16a34a", s=38, label="dorm/start")
    axes[0, 0].scatter(path.x[-1], path.y[-1], color="#dc2626", s=38, label="class/end")
    axes[0, 0].set_title("Route and tracked trajectory")
    axes[0, 0].set_xlabel("East [m]")
    axes[0, 0].set_ylabel("North [m]")
    axes[0, 0].axis("equal")
    route_x = np.concatenate((np.asarray(path.x), x))
    route_y = np.concatenate((np.asarray(path.y), y))
    x_margin = max(30.0, 0.08 * float(np.ptp(route_x)))
    y_margin = max(30.0, 0.08 * float(np.ptp(route_y)))
    axes[0, 0].set_xlim(float(np.min(route_x)) - x_margin, float(np.max(route_x)) + x_margin)
    axes[0, 0].set_ylim(float(np.min(route_y)) - y_margin, float(np.max(route_y)) + y_margin)
    axes[0, 0].legend(fontsize=8)

    axes[0, 1].plot(time, error, color="#7c3aed", linewidth=1.2)
    axes[0, 1].axhline(0.0, color="#111827", linewidth=0.8)
    axes[0, 1].fill_between(time, -0.5, 0.5, color="#dcfce7", alpha=0.55)
    axes[0, 1].set_title("Signed lateral tracking error")
    axes[0, 1].set_xlabel("Time [s]")
    axes[0, 1].set_ylabel("Error [m]")

    axes[0, 2].plot(time, target_speed, color="#64748b", linewidth=1.4, label="target")
    axes[0, 2].plot(time, speed, color="#059669", linewidth=1.3, label="actual")
    axes[0, 2].set_title("Longitudinal speed")
    axes[0, 2].set_xlabel("Time [s]")
    axes[0, 2].set_ylabel("Speed [m/s]")
    axes[0, 2].legend(fontsize=8)

    axes[1, 0].plot(time, steer, color="#ea580c", linewidth=1.2)
    axes[1, 0].set_title("Front road-wheel command")
    axes[1, 0].set_xlabel("Time [s]")
    axes[1, 0].set_ylabel("Steering [deg]")

    axes[1, 1].plot(time, curvature, color="#0f766e", linewidth=1.0, label="curvature")
    acceleration_axis = axes[1, 1].twinx()
    acceleration_axis.plot(
        time,
        normal_accel,
        color="#dc2626",
        linewidth=1.0,
        alpha=0.78,
        label="normal acceleration",
    )
    axes[1, 1].set_title("Curve demand")
    axes[1, 1].set_xlabel("Time [s]")
    axes[1, 1].set_ylabel("Curvature [1/m]", color="#0f766e")
    acceleration_axis.set_ylabel("Normal acceleration [m/s2]", color="#dc2626")

    axes[1, 2].axis("off")
    summary_lines = [
        "Navigation summary",
        "",
        f"Route length        {metrics['route_length_m']:.1f} m",
        f"Duration            {metrics['duration_s']:.1f} s",
        f"RMS lateral error   {metrics['rms_lateral_error_m']:.3f} m",
        f"95% lateral error   {metrics['p95_lateral_error_m']:.3f} m",
        f"Maximum error       {metrics['max_lateral_error_m']:.3f} m",
        f"Finish error        {metrics['finish_error_m']:.3f} m",
        f"Maximum steering    {metrics['max_steering_deg']:.2f} deg",
        f"Maximum speed       {metrics['max_speed_mps']:.2f} m/s",
        f"Reached goal        {metrics['reached_goal']}",
    ]
    axes[1, 2].text(
        0.03,
        0.96,
        "\n".join(summary_lines),
        va="top",
        ha="left",
        fontsize=11,
        family="monospace",
        linespacing=1.42,
    )

    for axis in axes.flat:
        if axis.axison:
            axis.grid(True, alpha=0.20)
    title = (
        "Dorm-to-class Adaptive Pure Pursuit Navigation"
        if route_confirmed
        else "Campus GPX Adaptive PP Simulation - Confirm Dorm/Class Endpoints"
    )
    fig.suptitle(title, fontsize=16)
    fig.savefig(output_file, dpi=180)
    plt.close(fig)


def save_metrics_json(output_file, metrics):
    Path(output_file).write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_route_check_csv(output_file, path):
    with Path(output_file).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["item", "value", "unit"])
        writer.writerow(["route_length", f"{path.s[-1]:.3f}", "m"])
        writer.writerow(["reference_points", len(path.x), "count"])
        if path.lat is not None and path.lon is not None:
            writer.writerow(["start_latitude", f"{path.lat[0]:.9f}", "deg"])
            writer.writerow(["start_longitude", f"{path.lon[0]:.9f}", "deg"])
            writer.writerow(["end_latitude", f"{path.lat[-1]:.9f}", "deg"])
            writer.writerow(["end_longitude", f"{path.lon[-1]:.9f}", "deg"])


def save_navigation_report(
    output_file,
    route_file,
    path,
    metrics,
    metadata,
    route_confirmed=False,
):
    start = (float(path.lat[0]), float(path.lon[0])) if path.lat is not None else None
    end = (float(path.lat[-1]), float(path.lon[-1])) if path.lat is not None else None
    lines = [
        "# Dorm-to-Class Navigation Result",
        "",
        "## Task Summary",
        "",
        "This experiment combines a campus route, vehicle parameters, an adaptive Pure Pursuit controller, closed-loop simulation, and quantitative evaluation. "
        + (
            "The start, destination, permitted route, and excluded road sections are taken from the annotated campus map."
            if route_confirmed
            else "The route has not yet been confirmed for a real-vehicle test."
        ),
        "",
        "## Route and Map",
        "",
        f"- GPX file: `{route_file}`",
        f"- Route length: {metrics['route_length_m']:.1f} m",
        f"- Source GPX points: {metadata.get('raw_point_count', 'n/a')}",
        f"- Resampled points: {metadata.get('resampled_point_count', len(path.x))}",
        f"- Maximum source-point spacing: {metadata.get('max_raw_gap_m', float('nan')):.1f} m",
    ]
    if start and end:
        lines.extend(
            [
                f"- Start: {start[0]:.7f}, {start[1]:.7f}",
                f"- Destination: {end[0]:.7f}, {end[1]:.7f}",
            ]
        )
    lines.extend(
        [
            "",
            "The route is converted from WGS84 coordinates to a local East-North frame in metres. The reference path and vehicle trajectory use the same origin as the offline OSM GeoJSON map. The current GPX was digitized from the annotated map and is a planning reference rather than a surveyed vehicle path.",
            "",
            "## Controller",
            "",
            "The controller selects its target by path distance. Lookahead increases with speed and lateral error, while curvature preview reduces the target speed before a sharp turn. The front road-wheel angle and its rate of change are limited using the vehicle parameters. A stopping-distance constraint reduces speed near the destination.",
            "",
            "## Tracking Result",
            "",
            "| Metric | Result |",
            "| --- | ---: |",
            f"| Destination reached | {metrics['reached_goal']} |",
            f"| Lateral-error RMSE | {metrics['rms_lateral_error_m']:.3f} m |",
            f"| Lateral-error P95 | {metrics['p95_lateral_error_m']:.3f} m |",
            f"| Maximum lateral error | {metrics['max_lateral_error_m']:.3f} m |",
            f"| Final position error | {metrics['finish_error_m']:.3f} m |",
            f"| Maximum road-wheel angle | {metrics['max_steering_deg']:.2f} deg |",
            f"| Maximum speed | {metrics['max_speed_mps']:.2f} m/s |",
            f"| Simulation time | {metrics['duration_s']:.1f} s |",
            "",
            "## Real-Vehicle Interface",
            "",
            "The supplied vehicle software provides path recording, PP tracking, and RViz display. Before a full test, the route should be recorded while the vehicle is driven manually at low speed. The test log should include `/gps_odom`, `/vehicleStateSet`, and `/vehicleCmdSet` so that the same metrics can be calculated from the real trajectory.",
            "",
            "## Limitation",
            "",
            "This result verifies the controller and analysis code on the map-derived route. It is not an autonomous real-vehicle result. Map alignment and positioning errors must be addressed by recording a dense GNSS/RTK route on site before vehicle operation.",
            "",
        ]
    )
    Path(output_file).write_text("\n".join(lines), encoding="utf-8")
