import numpy as np

from vdm_lab.common.types import VehicleConfig


# Vehicle geometry, limits, and dynamic parameters are kept in one place.
# Add a parameter set for a new vehicle instead of hard-coding values in a controller.
VEHICLE_PARAMETER_SETS = {
    "sydl_smartcar": {
        # Geometry and actuator limits come from the supplied ROS workspace.
        "wheelbase": 0.90,
        "width": 1.00,
        "front_overhang": 0.35,
        "rear_overhang": 0.25,
        "wheel_track": 0.75,
        "tire_radius": 0.20,
        "tire_width": 0.12,
        "max_steer": np.deg2rad(45.0),
        "max_steer_rate": np.deg2rad(180.0),
        "max_accel": 2.0,
        "max_decel": 6.0,
        "max_speed": 10.0 / 3.6,
        # Zero is required for a complete stop in the simulation. The real
        # chassis has a practical moving-speed floor near 2.5 km/h.
        "min_speed": 0.0,
        # The supplied files do not contain mass or tire-test results. These
        # values are explicit starting assumptions for dynamic-model fitting.
        "mass": 180.0,
        "inertia_z": 70.0,
        "lf": 0.45,
        "lr": 0.45,
        "cf": 12000.0,
        "cr": 12000.0,
    },
    "student_car": {
        "wheelbase": 2.50,
        "width": 1.80,
        "front_overhang": 0.90,
        "rear_overhang": 0.80,
        "wheel_track": 1.50,
        "tire_radius": 0.32,
        "tire_width": 0.22,
        "max_steer": np.deg2rad(35.0),
        "max_steer_rate": np.deg2rad(45.0),
        "max_accel": 2.0,
        "max_decel": 3.5,
        "max_speed": 12.0,
        "min_speed": 0.0,
        "mass": 1140.0,
        "inertia_z": 1436.24,
        "lf": 1.25,
        "lr": 1.25,
        "cf": 155494.663,
        "cr": 155494.663,
    },
    "compact_ev": {
        "wheelbase": 2.70,
        "width": 1.86,
        "front_overhang": 0.88,
        "rear_overhang": 0.82,
        "wheel_track": 1.58,
        "tire_radius": 0.34,
        "tire_width": 0.24,
        "max_steer": np.deg2rad(32.0),
        "max_steer_rate": np.deg2rad(42.0),
        "max_accel": 2.4,
        "max_decel": 4.0,
        "max_speed": 14.0,
        "min_speed": 0.0,
        "mass": 1650.0,
        "inertia_z": 2450.0,
        "lf": 1.35,
        "lr": 1.35,
        "cf": 150000.0,
        "cr": 152000.0,
    },
}


DEFAULT_VEHICLE_NAME = "student_car"


def available_vehicle_names():
    return tuple(VEHICLE_PARAMETER_SETS.keys())


def make_vehicle_config(name=DEFAULT_VEHICLE_NAME):
    try:
        params = VEHICLE_PARAMETER_SETS[name]
    except KeyError as exc:
        choices = ", ".join(available_vehicle_names())
        raise ValueError(f"Unknown vehicle parameter set {name}. Available sets: {choices}") from exc
    return VehicleConfig(**params)
