"""Metrics and plots for model comparison experiments."""

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def _angle_error(predicted, measured):
    delta = predicted - measured
    return np.arctan2(np.sin(delta), np.cos(delta))


def compute_prediction_metrics(data, prediction, start_index=0):
    section = slice(int(start_index), None)
    position_error = np.hypot(
        prediction.x[section] - data.x[section],
        prediction.y[section] - data.y[section],
    )
    yaw_error = _angle_error(prediction.yaw[section], data.yaw[section])
    yaw_rate_error = prediction.yaw_rate[section] - data.yaw_rate[section]
    return {
        "model": prediction.name,
        "position_rmse_m": float(np.sqrt(np.mean(position_error**2))),
        "position_p95_m": float(np.percentile(position_error, 95.0)),
        "final_position_error_m": float(position_error[-1]),
        "yaw_rmse_deg": float(np.rad2deg(np.sqrt(np.mean(yaw_error**2)))),
        "yaw_rate_rmse_degps": float(
            np.rad2deg(np.sqrt(np.mean(yaw_rate_error**2)))
        ),
    }


def save_metrics_csv(path, rows):
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_identified_parameters(path, parameters):
    with Path(path).open("w", encoding="utf-8") as stream:
        json.dump(parameters, stream, indent=2)


def save_model_comparison_plot(path, data, predictions, evaluation_start):
    colors = {
        "kinematic_rear": "#7c3aed",
        "kinematic_cg": "#2563eb",
        "dynamic_yaw": "#dc2626",
    }
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.5), constrained_layout=True)

    axes[0, 0].plot(data.x, data.y, color="#111827", linewidth=2.4, label="measurement")
    for prediction in predictions:
        axes[0, 0].plot(
            prediction.x,
            prediction.y,
            linewidth=1.4,
            color=colors[prediction.name],
            label=prediction.name,
        )
    axes[0, 0].set_title("Trajectory prediction")
    axes[0, 0].set_xlabel("East x [m]")
    axes[0, 0].set_ylabel("North y [m]")
    axes[0, 0].axis("equal")
    axes[0, 0].legend(fontsize=8)

    axes[0, 1].plot(
        data.time,
        np.rad2deg(data.yaw_rate),
        color="#111827",
        linewidth=2.0,
        label="measurement",
    )
    for prediction in predictions:
        axes[0, 1].plot(
            data.time,
            np.rad2deg(prediction.yaw_rate),
            color=colors[prediction.name],
            linewidth=1.2,
            label=prediction.name,
        )
    axes[0, 1].axvline(
        data.time[evaluation_start],
        color="#64748b",
        linestyle="--",
        linewidth=1.0,
        label="evaluation start",
    )
    axes[0, 1].set_title("Yaw-rate response")
    axes[0, 1].set_xlabel("Time [s]")
    axes[0, 1].set_ylabel("Yaw rate [deg/s]")
    axes[0, 1].legend(fontsize=8, ncol=2)

    for prediction in predictions:
        error = np.hypot(prediction.x - data.x, prediction.y - data.y)
        axes[1, 0].plot(
            data.time,
            error,
            color=colors[prediction.name],
            linewidth=1.3,
            label=prediction.name,
        )
    axes[1, 0].axvspan(
        data.time[evaluation_start],
        data.time[-1],
        color="#e2e8f0",
        alpha=0.45,
        label="held-out evaluation",
    )
    axes[1, 0].set_title("Position error")
    axes[1, 0].set_xlabel("Time [s]")
    axes[1, 0].set_ylabel("Error [m]")
    axes[1, 0].legend(fontsize=8)

    axes[1, 1].plot(
        data.time,
        data.speed,
        color="#059669",
        linewidth=1.8,
        label="speed",
    )
    steer_axis = axes[1, 1].twinx()
    steer_axis.plot(
        data.time,
        np.rad2deg(data.steering),
        color="#ea580c",
        linewidth=1.2,
        label="road-wheel angle",
    )
    axes[1, 1].set_title("Experiment excitation")
    axes[1, 1].set_xlabel("Time [s]")
    axes[1, 1].set_ylabel("Speed [m/s]", color="#059669")
    steer_axis.set_ylabel("Steering [deg]", color="#ea580c")

    for axis in axes.flat:
        axis.grid(True, alpha=0.22)
    fig.suptitle(
        "Vehicle model reconstruction - controlled synthetic benchmark",
        fontsize=15,
    )
    fig.savefig(path, dpi=180)
    plt.close(fig)
