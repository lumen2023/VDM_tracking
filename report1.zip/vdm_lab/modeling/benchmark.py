"""Deterministic benchmark data for testing the identification pipeline."""

import csv
from pathlib import Path

import numpy as np

from vdm_lab.modeling.data import ExperimentData
from vdm_lab.modeling.models import simulate_dynamic_yaw


TRUE_PARAMETERS = {
    "wheelbase_m": 0.94,
    "steering_bias_rad": np.deg2rad(1.2),
    "yaw_time_constant_s": 0.34,
    "understeer_s2pm": 0.045,
    "delay_s": 0.175,
}


def generate_benchmark(csv_file, seed=42):
    """Generate a noisy commanded-steering experiment from a hidden plant."""
    rng = np.random.default_rng(seed)
    time = np.arange(0.0, 90.0 + 0.05, 0.05)
    speed = 1.25 + 0.45 * np.sin(0.055 * time) + 0.12 * np.sin(0.31 * time)
    speed = np.clip(speed, 0.55, 1.85)
    steering = (
        np.deg2rad(9.0) * np.sin(0.22 * time)
        + np.deg2rad(4.5) * np.sin(0.071 * time + 0.7)
    )
    steering[(time > 34.0) & (time < 42.0)] += np.deg2rad(7.0)
    steering[(time > 65.0) & (time < 73.0)] -= np.deg2rad(6.0)

    blank = ExperimentData(
        time=time,
        speed=speed,
        steering=steering,
        x=np.zeros_like(time),
        y=np.zeros_like(time),
        yaw=np.zeros_like(time),
        yaw_rate=np.zeros_like(time),
        source="controlled synthetic benchmark",
    )
    truth = simulate_dynamic_yaw(blank, **TRUE_PARAMETERS)

    measured_x = truth.x + rng.normal(0.0, 0.025, len(time))
    measured_y = truth.y + rng.normal(0.0, 0.025, len(time))
    measured_yaw = truth.yaw + rng.normal(0.0, np.deg2rad(0.18), len(time))
    measured_yaw_rate = truth.yaw_rate + rng.normal(
        0.0, np.deg2rad(0.35), len(time)
    )

    csv_file = Path(csv_file)
    csv_file.parent.mkdir(parents=True, exist_ok=True)
    with csv_file.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "time_s",
                "speed_mps",
                "steering_rad",
                "x_m",
                "y_m",
                "yaw_rad",
                "yaw_rate_radps",
            ]
        )
        for row in zip(
            time,
            speed,
            steering,
            measured_x,
            measured_y,
            measured_yaw,
            measured_yaw_rate,
        ):
            writer.writerow([f"{value:.9f}" for value in row])
    return csv_file
