"""Input validation for normalized vehicle experiment CSV files."""

from dataclasses import dataclass
import csv
from pathlib import Path

import numpy as np


REQUIRED_COLUMNS = (
    "time_s",
    "speed_mps",
    "steering_rad",
    "x_m",
    "y_m",
    "yaw_rad",
)


@dataclass(frozen=True)
class ExperimentData:
    time: np.ndarray
    speed: np.ndarray
    steering: np.ndarray
    x: np.ndarray
    y: np.ndarray
    yaw: np.ndarray
    yaw_rate: np.ndarray
    source: str = "unknown"

    def __post_init__(self):
        lengths = {
            len(self.time),
            len(self.speed),
            len(self.steering),
            len(self.x),
            len(self.y),
            len(self.yaw),
            len(self.yaw_rate),
        }
        if len(lengths) != 1 or next(iter(lengths)) < 10:
            raise ValueError("Experiment arrays must have one common length of at least 10.")
        if np.any(np.diff(self.time) <= 0.0):
            raise ValueError("time_s must be strictly increasing.")
        for values in (
            self.time,
            self.speed,
            self.steering,
            self.x,
            self.y,
            self.yaw,
            self.yaw_rate,
        ):
            if not np.all(np.isfinite(values)):
                raise ValueError("Experiment columns must contain only finite numeric values.")

    @property
    def duration_s(self):
        return float(self.time[-1] - self.time[0])

    @property
    def median_dt_s(self):
        return float(np.median(np.diff(self.time)))


def _numeric_column(rows, name):
    try:
        return np.asarray([float(row[name]) for row in rows], dtype=float)
    except KeyError as exc:
        raise ValueError(f"Missing required column: {name}") from exc
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Column {name} contains a non-numeric or empty value.") from exc


def _derive_yaw_rate(time, yaw):
    unwrapped = np.unwrap(yaw)
    yaw_rate = np.gradient(unwrapped, time, edge_order=1)
    if len(yaw_rate) >= 9:
        # A short symmetric filter reduces GNSS heading differentiation noise.
        kernel = np.array([1, 2, 3, 4, 5, 4, 3, 2, 1], dtype=float)
        kernel /= kernel.sum()
        yaw_rate = np.convolve(yaw_rate, kernel, mode="same")
    return yaw_rate


def load_experiment_csv(csv_file):
    """Load a normalized log and derive yaw rate when it is not supplied."""
    path = Path(csv_file)
    with path.open("r", newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)

    if not rows:
        raise ValueError(f"Experiment CSV is empty: {path}")
    missing = [name for name in REQUIRED_COLUMNS if name not in rows[0]]
    if missing:
        raise ValueError(
            "Experiment CSV is missing columns: " + ", ".join(missing)
        )

    time = _numeric_column(rows, "time_s")
    time = time - time[0]
    yaw = np.unwrap(_numeric_column(rows, "yaw_rad"))
    derived_yaw_rate = _derive_yaw_rate(time, yaw)
    if "yaw_rate_radps" in rows[0] and all(
        row.get("yaw_rate_radps", "").strip() for row in rows
    ):
        yaw_rate = _numeric_column(rows, "yaw_rate_radps")
        # Some GNSS odometry drivers publish a permanently zero angular rate.
        # Fall back to differentiated heading when the trajectory clearly turns.
        if np.std(yaw_rate) < 1.0e-5 and np.std(derived_yaw_rate) > 1.0e-3:
            yaw_rate = derived_yaw_rate
    else:
        yaw_rate = derived_yaw_rate

    return ExperimentData(
        time=time,
        speed=_numeric_column(rows, "speed_mps"),
        steering=_numeric_column(rows, "steering_rad"),
        x=_numeric_column(rows, "x_m"),
        y=_numeric_column(rows, "y_m"),
        yaw=yaw,
        yaw_rate=yaw_rate,
        source=str(path),
    )
