"""Reconstructed kinematic and reduced dynamic bicycle models."""

from dataclasses import dataclass

import numpy as np

from vdm_lab.modeling.data import ExperimentData


@dataclass(frozen=True)
class ModelPrediction:
    name: str
    time: np.ndarray
    x: np.ndarray
    y: np.ndarray
    yaw: np.ndarray
    yaw_rate: np.ndarray
    beta: np.ndarray


def _delayed_steering(data, delay_s, steering_bias_rad=0.0):
    sample_time = data.time - max(float(delay_s), 0.0)
    steering = np.interp(
        sample_time,
        data.time,
        data.steering,
        left=float(data.steering[0]),
        right=float(data.steering[-1]),
    )
    return steering - float(steering_bias_rad)


def _initial_arrays(data):
    count = len(data.time)
    x = np.empty(count, dtype=float)
    y = np.empty(count, dtype=float)
    yaw = np.empty(count, dtype=float)
    yaw_rate = np.zeros(count, dtype=float)
    beta = np.zeros(count, dtype=float)
    x[0] = data.x[0]
    y[0] = data.y[0]
    yaw[0] = data.yaw[0]
    return x, y, yaw, yaw_rate, beta


def simulate_kinematic_rear(
    data: ExperimentData,
    wheelbase_m,
    steering_bias_rad=0.0,
    delay_s=0.0,
):
    """Rear-axle bicycle model with no body slip."""
    wheelbase = max(float(wheelbase_m), 1.0e-3)
    steering = _delayed_steering(data, delay_s, steering_bias_rad)
    x, y, yaw, yaw_rate, beta = _initial_arrays(data)

    for index in range(len(data.time) - 1):
        dt = float(data.time[index + 1] - data.time[index])
        speed = float(data.speed[index])
        yaw_rate[index] = speed * np.tan(steering[index]) / wheelbase
        x[index + 1] = x[index] + speed * np.cos(yaw[index]) * dt
        y[index + 1] = y[index] + speed * np.sin(yaw[index]) * dt
        yaw[index + 1] = yaw[index] + yaw_rate[index] * dt
    yaw_rate[-1] = yaw_rate[-2]
    return ModelPrediction(
        "kinematic_rear", data.time, x, y, yaw, yaw_rate, beta
    )


def simulate_kinematic_cg(
    data: ExperimentData,
    wheelbase_m,
    rear_length_m=None,
    steering_bias_rad=0.0,
    delay_s=0.0,
):
    """Center-of-gravity kinematic bicycle model with geometric slip angle."""
    wheelbase = max(float(wheelbase_m), 1.0e-3)
    rear_length = wheelbase / 2.0 if rear_length_m is None else rear_length_m
    steering = _delayed_steering(data, delay_s, steering_bias_rad)
    x, y, yaw, yaw_rate, beta = _initial_arrays(data)

    for index in range(len(data.time) - 1):
        dt = float(data.time[index + 1] - data.time[index])
        speed = float(data.speed[index])
        beta[index] = np.arctan2(
            rear_length * np.tan(steering[index]),
            wheelbase,
        )
        yaw_rate[index] = (
            speed * np.tan(steering[index]) * np.cos(beta[index]) / wheelbase
        )
        x[index + 1] = x[index] + speed * np.cos(yaw[index] + beta[index]) * dt
        y[index + 1] = y[index] + speed * np.sin(yaw[index] + beta[index]) * dt
        yaw[index + 1] = yaw[index] + yaw_rate[index] * dt
    beta[-1] = beta[-2]
    yaw_rate[-1] = yaw_rate[-2]
    return ModelPrediction(
        "kinematic_cg", data.time, x, y, yaw, yaw_rate, beta
    )


def simulate_dynamic_yaw(
    data: ExperimentData,
    wheelbase_m,
    steering_bias_rad=0.0,
    yaw_time_constant_s=0.25,
    understeer_s2pm=0.0,
    delay_s=0.0,
    rear_length_m=None,
):
    """Reduced dynamic bicycle model with yaw/slip lag and understeer."""
    wheelbase = max(float(wheelbase_m), 1.0e-3)
    rear_length = wheelbase / 2.0 if rear_length_m is None else rear_length_m
    tau = max(float(yaw_time_constant_s), 1.0e-3)
    understeer = max(float(understeer_s2pm), 0.0)
    steering = _delayed_steering(data, delay_s, steering_bias_rad)
    x, y, yaw, yaw_rate, beta = _initial_arrays(data)
    yaw_rate[0] = float(data.yaw_rate[0])

    for index in range(len(data.time) - 1):
        dt = float(data.time[index + 1] - data.time[index])
        speed = max(float(data.speed[index]), 0.0)
        denominator = wheelbase + understeer * speed * speed
        steady_yaw_rate = speed * np.tan(steering[index]) / denominator
        steady_beta = np.arctan2(
            rear_length * np.tan(steering[index]),
            denominator,
        )

        gain = min(dt / tau, 1.0)
        yaw_rate[index + 1] = yaw_rate[index] + gain * (
            steady_yaw_rate - yaw_rate[index]
        )
        beta[index + 1] = beta[index] + gain * (steady_beta - beta[index])
        x[index + 1] = x[index] + speed * np.cos(yaw[index] + beta[index]) * dt
        y[index + 1] = y[index] + speed * np.sin(yaw[index] + beta[index]) * dt
        yaw[index + 1] = yaw[index] + yaw_rate[index] * dt

    return ModelPrediction(
        "dynamic_yaw", data.time, x, y, yaw, yaw_rate, beta
    )
