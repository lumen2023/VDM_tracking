"""Parameter identification for the reduced dynamic yaw model."""

import numpy as np
from scipy.optimize import least_squares

from vdm_lab.modeling.models import simulate_dynamic_yaw


def identify_dynamic_yaw_model(data, nominal_wheelbase_m, calibration_ratio=0.60):
    """Fit wheelbase, bias, yaw lag, understeer, and steering delay."""
    if not 0.3 <= calibration_ratio <= 0.9:
        raise ValueError("calibration_ratio must be between 0.3 and 0.9.")

    split = max(10, min(int(len(data.time) * calibration_ratio), len(data.time) - 5))
    valid = (data.speed[:split] > 0.25) & (
        np.abs(data.steering[:split]) > np.deg2rad(0.5)
    )
    if np.count_nonzero(valid) < 8:
        raise ValueError("The calibration interval has insufficient steering excitation.")

    wheelbase_low = max(0.25, nominal_wheelbase_m * 0.45)
    wheelbase_high = max(wheelbase_low + 0.1, nominal_wheelbase_m * 2.2)
    lower = np.array([wheelbase_low, -np.deg2rad(10.0), 0.03, 0.0])
    upper = np.array([wheelbase_high, np.deg2rad(10.0), 2.0, 1.0])
    initial = np.array([nominal_wheelbase_m, 0.0, 0.25, 0.02])

    best = None
    for delay_s in np.linspace(0.0, 0.60, 25):
        def residual(parameters):
            prediction = simulate_dynamic_yaw(
                data,
                wheelbase_m=parameters[0],
                steering_bias_rad=parameters[1],
                yaw_time_constant_s=parameters[2],
                understeer_s2pm=parameters[3],
                delay_s=delay_s,
            )
            return prediction.yaw_rate[:split][valid] - data.yaw_rate[:split][valid]

        result = least_squares(
            residual,
            initial,
            bounds=(lower, upper),
            loss="soft_l1",
            f_scale=np.deg2rad(1.0),
            max_nfev=300,
        )
        score = float(np.mean(residual(result.x) ** 2))
        if best is None or score < best[0]:
            best = (score, delay_s, result)
            initial = result.x

    _, delay_s, result = best
    return {
        "wheelbase_m": float(result.x[0]),
        "steering_bias_rad": float(result.x[1]),
        "yaw_time_constant_s": float(result.x[2]),
        "understeer_s2pm": float(result.x[3]),
        "delay_s": float(delay_s),
        "calibration_samples": int(split),
        "evaluation_samples": int(len(data.time) - split),
        "optimizer_cost": float(result.cost),
        "optimizer_success": bool(result.success),
    }
