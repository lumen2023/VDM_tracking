"""Adaptive Pure Pursuit controller for the campus navigation task."""

import math

import numpy as np

from vdm_lab.common.geometry import clamp, pi_to_pi
from vdm_lab.common.types import ControlCommand
from vdm_lab.common.vehicle import speed_pid


NAME = "Adaptive Pure Pursuit"


def _lookahead_distance(state, reference, controller):
    """Return a bounded lookahead that grows with speed and tracking error."""
    lookahead = (
        controller.pp_base_lookahead
        + controller.pp_speed_gain * state.v
        + controller.pp_lateral_error_gain * abs(reference.lateral_error)
    )
    return clamp(
        lookahead,
        controller.pp_min_lookahead,
        controller.pp_max_lookahead,
    )


def _target_index(path, nearest_index, lookahead):
    """Select a forward point by path arc length instead of point count."""
    target_s = float(path.s[nearest_index]) + lookahead
    return min(int(np.searchsorted(path.s, target_s)), len(path.x) - 1)


def _preview_speed(path, nearest_index, reference_speed, controller):
    """Limit speed using the largest previewed path curvature."""
    end_s = float(path.s[nearest_index]) + controller.pp_curvature_preview_m
    end_index = min(int(np.searchsorted(path.s, end_s)), len(path.x) - 1)
    preview = np.abs(path.curvature[nearest_index : end_index + 1])
    if preview.size == 0:
        return float(reference_speed)

    # A high percentile is less sensitive to a single noisy GPX derivative.
    curvature = float(np.percentile(preview, 95.0))
    if curvature < 1.0e-5:
        return float(reference_speed)
    curve_speed = math.sqrt(controller.pp_max_lateral_accel / curvature)
    return min(float(reference_speed), curve_speed)


def control(state, reference, previous_control, config):
    """Compute acceleration and front-road-wheel angle in SI units."""
    path = reference.path
    controller = config.controller
    vehicle = config.vehicle

    lookahead = _lookahead_distance(state, reference, controller)
    target_index = _target_index(path, reference.nearest_index, lookahead)
    dx = float(path.x[target_index] - state.x)
    dy = float(path.y[target_index] - state.y)
    target_distance = max(math.hypot(dx, dy), 1.0e-6)
    alpha = pi_to_pi(math.atan2(dy, dx) - state.yaw)

    steer = math.atan2(
        2.0 * vehicle.wheelbase * math.sin(alpha),
        target_distance,
    )
    steer = clamp(steer, -vehicle.max_steer, vehicle.max_steer)

    # Respect the physical road-wheel slew rate to avoid an optimistic model.
    max_step = vehicle.max_steer_rate * config.sim.dt
    steer = clamp(
        steer,
        previous_control.steer - max_step,
        previous_control.steer + max_step,
    )

    goal_distance = math.hypot(state.x - path.x[-1], state.y - path.y[-1])
    target_speed = _preview_speed(
        path,
        reference.nearest_index,
        reference.target_speed,
        controller,
    )
    acceleration = speed_pid(
        target_speed,
        state.v,
        goal_distance,
        controller,
        vehicle,
    )
    return ControlCommand(acceleration=acceleration, steer=steer)
