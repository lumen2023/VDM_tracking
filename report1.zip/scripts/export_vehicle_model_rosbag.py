#!/usr/bin/env python3
"""Export ROS1 vehicle topics to the normalized model-comparison CSV format."""

import argparse
import csv
import math

import rosbag


def quaternion_to_yaw(orientation):
    sin_yaw = 2.0 * (
        orientation.w * orientation.z + orientation.x * orientation.y
    )
    cos_yaw = 1.0 - 2.0 * (
        orientation.y * orientation.y + orientation.z * orientation.z
    )
    return math.atan2(sin_yaw, cos_yaw)


def message_time(message, bag_time):
    if hasattr(message, "header") and message.header.stamp.to_sec() > 0.0:
        return message.header.stamp.to_sec()
    return bag_time.to_sec()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bag")
    parser.add_argument("output_csv")
    parser.add_argument(
        "--steering-source",
        choices=("actual", "command"),
        default="actual",
    )
    args = parser.parse_args()

    state = None
    command = None
    rows = []
    topics = ("/gps_odom", "/vehicleStateSet", "/vehicleCmdSet")
    with rosbag.Bag(args.bag, "r") as bag:
        for topic, message, bag_time in bag.read_messages(topics=topics):
            if topic == "/vehicleStateSet":
                state = message
                continue
            if topic == "/vehicleCmdSet":
                command = message
                continue
            steering_message = state if args.steering_source == "actual" else command
            if state is None or steering_message is None:
                continue

            rows.append(
                {
                    "time_s": message_time(message, bag_time),
                    "speed_mps": float(state.speed) / 3.6,
                    "steering_rad": math.radians(
                        float(steering_message.roadwheel_angle)
                    ),
                    "x_m": float(message.pose.pose.position.x),
                    "y_m": float(message.pose.pose.position.y),
                    "yaw_rad": quaternion_to_yaw(message.pose.pose.orientation),
                    "yaw_rate_radps": float(message.twist.twist.angular.z),
                }
            )

    if len(rows) < 10:
        raise RuntimeError(
            "Fewer than 10 synchronized odometry samples were found. "
            "Check the three topic names and bag contents."
        )
    start_time = rows[0]["time_s"]
    for row in rows:
        row["time_s"] -= start_time

    with open(args.output_csv, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} samples to {args.output_csv}")


if __name__ == "__main__":
    main()
