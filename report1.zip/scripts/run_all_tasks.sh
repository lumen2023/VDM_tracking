#!/usr/bin/env bash
set -euo pipefail

python3 run_model_comparison.py --generate-benchmark
python3 run_navigation_task.py
python3 -m unittest discover -s tests -v
