# Vehicle Kinematic and Dynamic Model Reconstruction

## 1. Objective and Available Data

This part compares vehicle models with different levels of complexity. The main question is whether a kinematic model is sufficient for low-speed path tracking and how the result changes when steering delay and yaw dynamics are included.

All models receive the same measured speed and front road-wheel angle and start from the same pose. Their predicted position, heading, and yaw rate are compared on a held-out section of the dataset.

The supplied vehicle files specify a wheelbase of 0.90 m, a track width of 0.75 m, a vehicle width of 1.00 m, a vehicle length of 1.50 m, a front road-wheel limit of +/-45 degrees, and a maximum speed of 10 km/h. Mass, yaw inertia, and tire cornering stiffness are not available, so they are not treated as identified vehicle parameters.

The normalized input format is:

```text
time_s,speed_mps,steering_rad,x_m,y_m,yaw_rad,yaw_rate_radps
```

## 2. Rear-Axle Kinematic Model

The rear-axle model assumes no body slip:

```text
x_dot   = v*cos(psi)
y_dot   = v*sin(psi)
psi_dot = v*tan(delta)/L
```

This model is inexpensive and works well at low speed when steering changes are slow. It cannot represent actuator delay or yaw-response lag.

## 3. Center-of-Gravity Kinematic Model

The center-of-gravity model includes a geometric slip angle:

```text
beta    = atan(lr*tan(delta)/L)
x_dot   = v*cos(psi + beta)
y_dot   = v*sin(psi + beta)
psi_dot = v*tan(delta)*cos(beta)/L
```

It gives a better geometric description of the center-of-gravity trajectory during a turn. However, the response to steering is still instantaneous, so the model cannot reproduce phase lag during faster steering inputs.

## 4. Reduced Dynamic Yaw Model

The available ROS topics provide speed, road-wheel angle, pose, and yaw rate, but they do not provide tire lateral forces or center-of-gravity lateral velocity. I therefore used a reduced model that can be identified from the available signals:

```text
r_ss = v*tan(delta - b)/(L_eff + K_u*v^2)
tau_r*r_dot + r = r_ss
psi_dot = r
```

`L_eff` is the effective wheelbase, `b` is steering bias, `K_u` is an understeer coefficient, and `tau_r` is the yaw-rate time constant. A fixed steering-input delay is also estimated. This model captures the main observable effects without fitting an underdetermined full tire model.

## 5. Identification and Evaluation

The first 60% of the samples are used for calibration. A grid search is used for steering delay, and bounded robust least squares is used for the remaining parameters. The final 40% of the samples are not used during fitting.

The three models share the identified effective wheelbase, steering bias, and delay. This keeps the comparison focused on model structure. The evaluation metrics are position RMSE, position P95, final position error, heading RMSE, and yaw-rate RMSE.

## 6. Current Result

The supplied `robot_car.bag` contains no topics or messages. I used a deterministic synthetic dataset with added measurement noise, steering delay, yaw lag, and understeer to verify the identification code.

| Model | Position RMSE | Heading RMSE | Yaw-rate RMSE |
| --- | ---: | ---: | ---: |
| Rear-axle kinematic | 10.003 m | 5.561 deg | 0.883 deg/s |
| Center-of-gravity kinematic | 9.469 m | 5.338 deg | 0.879 deg/s |
| Reduced dynamic yaw | 0.296 m | 1.149 deg | 0.347 deg/s |

The dynamic model gives the smallest error because the benchmark contains the same types of delay and yaw dynamics represented by that model. This result verifies the implementation, but it is not a real-vehicle conclusion.

## 7. Planned Real-Vehicle Experiment

The real-vehicle dataset should contain:

1. constant-speed straight runs for steering bias and localization drift;
2. fixed-steering circles at two low speeds for effective wheelbase and steady-state gain;
3. left-right sinusoidal steering at several frequencies for delay and yaw time constant;
4. repeated runs of the same route at different speeds to identify the limit of the kinematic models.

The required ROS topics are `/gps_odom`, `/vehicleStateSet`, and `/vehicleCmdSet`. After conversion to the normalized CSV format, the same program can be run with:

```bash
python3 run_model_comparison.py \
  --input data/modeling/real_vehicle.csv \
  --output-dir results/model_comparison_real
```
