# Dorm-to-Class Navigation with Adaptive Pure Pursuit

## 1. Route Definition

The route is based on the annotated campus map in `docs/assets/dorm_to_class_annotated_map.jpg`. The southeast orange marker is the starting point and the northwest orange marker is the destination. I followed the yellow line and excluded the two red hatched road sections.

The digitized route is stored in:

```text
data/gpx/dorm_to_class_map_route.gpx
```

It starts near the Meiyuan residential area, travels west, turns north along the road on the west side of the restricted section, and then turns west toward the teaching buildings. The route contains 50 source points, has a maximum point spacing of 19.0 m, and is approximately 798.2 m long.

The GPX is a planning route derived from the map scale and the offline campus map. It is suitable for simulation, but it is not a surveyed or vehicle-recorded path.

## 2. Coordinate and Map Processing

The GPX latitude and longitude values are converted to a local East-North frame in metres. Consecutive duplicate points are removed, and the route is resampled at 0.5 m intervals. Heading and curvature are then calculated from the resampled path.

The background is the offline OSM GeoJSON file already included in the repository. The map, reference path, and simulated trajectory use the same coordinate origin.

Run the simulation from the repository root:

```bash
python3 run_navigation_task.py
```

A replacement GPX can be tested with:

```bash
python3 run_navigation_task.py \
  --gpx data/gpx/new_route.gpx \
  --target-speed 1.2 \
  --output-dir results/new_route \
  --strict-route \
  --unconfirmed-route
```

The `--strict-route` option rejects a GPX if the distance between two source points exceeds 50 m.

## 3. Adaptive Pure Pursuit Controller

The controller searches for a target point by path distance rather than by point count. Its lookahead distance is

```text
Ld = clamp(L0 + kv*v + ke*|ey|, Lmin, Lmax)
```

where `v` is vehicle speed and `ey` is lateral error. The front road-wheel command is calculated from the target-point geometry:

```text
delta = atan2(2*L*sin(alpha), d)
```

Here, `L` is the wheelbase, `alpha` is the target bearing relative to the vehicle heading, and `d` is the actual distance to the target point.

The implementation also previews path curvature. The target speed is reduced before a sharp turn so that the estimated lateral acceleration remains below the selected limit. Steering angle and steering rate are limited using the real vehicle parameters, and the longitudinal controller reduces speed near the final point.

## 4. Vehicle Interface

The parameters and topics below were taken from the supplied vehicle workspace.

| Item | Value |
| --- | --- |
| Position input | `/gps_odom` |
| Vehicle state | `/vehicleStateSet` |
| Vehicle command | `/vehicleCmdSet` |
| Wheelbase | 0.90 m |
| Vehicle width | 1.00 m |
| Vehicle length | 1.50 m |
| Maximum front road-wheel angle | +/-45 deg |
| Configured maximum speed | 10 km/h |
| Nominal control rate | 30 Hz |

The Python controller uses metres, seconds, and radians. A ROS interface must explicitly convert vehicle speed from km/h to m/s and road-wheel angle from degrees to radians.

## 5. Simulation Result

| Metric | Result |
| --- | ---: |
| Route length | 798.2 m |
| Lateral-error RMSE | 0.033 m |
| Lateral-error P95 | 0.011 m |
| Maximum lateral error | 0.595 m |
| Final position error | 0.028 m |
| Maximum road-wheel angle | 33.36 deg |
| Maximum speed | 1.50 m/s |
| Destination reached | Yes |

The largest error occurs during a sharp direction change near a corner. For most of the route, the lateral error remains close to zero. The speed reduction around the two main turns keeps the steering demand within the vehicle limit.

## 6. Real-Vehicle Test Plan

Before a vehicle test, the planned route should be recorded again on site. The vehicle can be driven manually at low speed along the road centre while GNSS/RTK data are recorded. The recorded path should then replace the map-derived GPX.

The first test should use a short straight segment, followed by one turn, before attempting the full route. The physical emergency stop and manual takeover must remain available. The test log should include `/gps_odom`, `/vehicleStateSet`, and `/vehicleCmdSet` so that the same error metrics can be calculated from real data.
