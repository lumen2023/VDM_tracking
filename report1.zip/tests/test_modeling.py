import tempfile
import unittest
from pathlib import Path

from vdm_lab.modeling.benchmark import generate_benchmark
from vdm_lab.modeling.comparison import compute_prediction_metrics
from vdm_lab.modeling.data import load_experiment_csv
from vdm_lab.modeling.identification import identify_dynamic_yaw_model
from vdm_lab.modeling.models import (
    simulate_dynamic_yaw,
    simulate_kinematic_rear,
)


class ModelIdentificationTests(unittest.TestCase):
    def test_dynamic_model_improves_held_out_yaw_rate(self):
        with tempfile.TemporaryDirectory() as directory:
            csv_file = generate_benchmark(Path(directory) / "benchmark.csv")
            data = load_experiment_csv(csv_file)
            parameters = identify_dynamic_yaw_model(data, 0.90, 0.60)
            split = parameters["calibration_samples"]

            common = {
                "wheelbase_m": parameters["wheelbase_m"],
                "steering_bias_rad": parameters["steering_bias_rad"],
                "delay_s": parameters["delay_s"],
            }
            kinematic = simulate_kinematic_rear(data, **common)
            dynamic = simulate_dynamic_yaw(
                data,
                yaw_time_constant_s=parameters["yaw_time_constant_s"],
                understeer_s2pm=parameters["understeer_s2pm"],
                **common,
            )
            kinematic_metrics = compute_prediction_metrics(data, kinematic, split)
            dynamic_metrics = compute_prediction_metrics(data, dynamic, split)

            self.assertTrue(parameters["optimizer_success"])
            self.assertLess(
                dynamic_metrics["yaw_rate_rmse_degps"],
                kinematic_metrics["yaw_rate_rmse_degps"],
            )
            self.assertGreater(parameters["wheelbase_m"], 0.5)
            self.assertLess(parameters["wheelbase_m"], 1.5)


if __name__ == "__main__":
    unittest.main()
