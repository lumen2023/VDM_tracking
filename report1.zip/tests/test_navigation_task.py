import unittest
from pathlib import Path

import numpy as np

from vdm_lab.common.path import generate_reference_path
from vdm_lab.common.gpx import generate_gpx_path
from vdm_lab.common.simulation import run_simulation
from vdm_lab.common.types import LabConfig
from vdm_lab.config.vehicle_params import make_vehicle_config
from vdm_lab.navigation import compute_navigation_metrics
from vdm_lab.solutions import adaptive_pure_pursuit


class NavigationTaskTests(unittest.TestCase):
    def test_default_dorm_to_class_route_is_dense_and_has_expected_endpoints(self):
        route_file = Path("data/gpx/dorm_to_class_map_route.gpx")
        path = generate_gpx_path(route_file, ds=0.5, target_speed=1.5)
        metadata = path.gpx_metadata

        self.assertTrue(route_file.is_file())
        self.assertLess(metadata["max_raw_gap_m"], 50.0)
        self.assertAlmostEqual(metadata["route_length_m"], 798.2, delta=5.0)
        self.assertAlmostEqual(float(path.lat[0]), 31.8856980, places=6)
        self.assertAlmostEqual(float(path.lon[0]), 118.8223350, places=6)
        self.assertAlmostEqual(float(path.lat[-1]), 31.8889160, places=6)
        self.assertAlmostEqual(float(path.lon[-1]), 118.8181900, places=6)

    def test_adaptive_pp_reaches_a_smooth_route_goal(self):
        waypoints = np.array(
            [
                [0.0, 0.0],
                [10.0, 0.0],
                [20.0, 4.0],
                [30.0, 4.0],
                [40.0, 0.0],
            ]
        )
        path = generate_reference_path(
            waypoints=waypoints,
            ds=0.25,
            target_speed=1.2,
        )
        config = LabConfig(vehicle=make_vehicle_config("sydl_smartcar"))
        config.sim.dt = 0.05
        config.sim.max_time = 90.0
        config.controller.pp_base_lookahead = 1.2
        config.controller.pp_speed_gain = 0.8
        config.controller.pp_max_lookahead = 4.0

        _, records, _ = run_simulation(
            adaptive_pure_pursuit,
            config=config,
            path_override=path,
        )
        metrics = compute_navigation_metrics(path, records)

        self.assertTrue(metrics["reached_goal"])
        self.assertLess(metrics["p95_lateral_error_m"], 0.75)
        self.assertLess(metrics["finish_error_m"], 1.5)


if __name__ == "__main__":
    unittest.main()
